﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessFileIO.Enums
{
    public enum PieceTypes
    {
        King,
        Queen,
        Bishop,
        Knight,
        Rook,
        Pawn
    }

    
}
